export * from './compiled-types/components/HomePage/HomePage';
export { default } from './compiled-types/components/HomePage/HomePage';