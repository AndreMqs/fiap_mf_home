export default function HeaderHomePage(): import("react/jsx-runtime").JSX.Element;
