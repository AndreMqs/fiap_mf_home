export default function HomePage(props: HomePageProps): import("react/jsx-runtime").JSX.Element;
interface HomePageProps {
}
export {};
