export default function ContentHomePage(): import("react/jsx-runtime").JSX.Element;
