export default function FooterHomePage(): import("react/jsx-runtime").JSX.Element;
